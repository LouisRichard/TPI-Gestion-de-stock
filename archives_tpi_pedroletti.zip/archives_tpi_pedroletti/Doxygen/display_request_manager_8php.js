var display_request_manager_8php =
[
    [ "getAllConsumables", "display_request_manager_8php.html#af9c6fca62b956e77628907f450ea0d4e", null ],
    [ "getBrands", "display_request_manager_8php.html#a35904b014f4ed06ee34df75a1d68ad35", null ],
    [ "getConsumableTypes", "display_request_manager_8php.html#af56e3591ef04a3e2c7b16873e5121bcc", null ],
    [ "getProducts", "display_request_manager_8php.html#a9686a480a1adb1923d64e71cf0624275", null ],
    [ "getUsersInformation", "display_request_manager_8php.html#aff8789f625cbe53d0a9e2d7dd7f3fe8b", null ]
];