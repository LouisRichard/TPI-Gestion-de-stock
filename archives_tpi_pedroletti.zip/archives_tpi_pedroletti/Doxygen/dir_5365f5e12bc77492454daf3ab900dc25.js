var dir_5365f5e12bc77492454daf3ab900dc25 =
[
    [ "adminPanel.php", "admin_panel_8php.html", "admin_panel_8php" ],
    [ "home.php", "home_8php.html", "home_8php" ],
    [ "login.php", "login_8php.html", "login_8php" ],
    [ "newConsumable.php", "new_consumable_8php.html", "new_consumable_8php" ],
    [ "template.php", "template_8php.html", "template_8php" ]
];