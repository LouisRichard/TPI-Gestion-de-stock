var db_connector_8php =
[
    [ "executeQuery", "db_connector_8php.html#abade937f092b460cbd342e5ed7bc4813", null ],
    [ "openDBConnexion", "db_connector_8php.html#ac86d33cb4865279fe9c2bde1d1e8d14d", null ]
];