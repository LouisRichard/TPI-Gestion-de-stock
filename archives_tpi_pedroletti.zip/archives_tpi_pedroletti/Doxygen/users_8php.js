var users_8php =
[
    [ "createSession", "users_8php.html#a5a8cc179982b6acb5e68e9acdb8d08a7", null ],
    [ "login", "users_8php.html#a476e4b9201ae45a95aff7623ba709bed", null ],
    [ "logOut", "users_8php.html#a9dbc3f3370308b59b039afc9a48381b3", null ],
    [ "saveAdminModification", "users_8php.html#abfd1f5041482d929b5309b17287122e4", null ]
];