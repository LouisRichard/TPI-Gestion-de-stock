var change_users_status_8php =
[
    [ "$id", "change_users_status_8php.html#ae97941710d863131c700f069b109991e", null ],
    [ "$status", "change_users_status_8php.html#a58391ea75f2d29d5d708d7050b641c33", null ]
];