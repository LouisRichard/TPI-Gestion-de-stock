var set_stock_8php =
[
    [ "$query", "set_stock_8php.html#af59a5f7cd609e592c41dc3643efd3c98", null ],
    [ "$strSep", "set_stock_8php.html#a2c1a39de519176a6331e7495123530b5", null ],
    [ "$userId", "set_stock_8php.html#a84651f4070d04080f6c5fd3c98cc9104", null ]
];