var users_manager_8php =
[
    [ "adVerification", "users_manager_8php.html#a92aab3e3d8f53469c9af814fc33fdba5", null ],
    [ "getUserInformation", "users_manager_8php.html#a2868eedd64b8298c9c46556c84ed0748", null ],
    [ "getUsersConnectionInformation", "users_manager_8php.html#a432b2c385deacf88f0b1b123884d5e44", null ],
    [ "getUsersID", "users_manager_8php.html#ae5b3902b6ff7fd4a25b93defe7b429de", null ],
    [ "setStatusUserAdmin", "users_manager_8php.html#aee7253bd3b242ee474676bfa143bd6be", null ],
    [ "userConnection", "users_manager_8php.html#adee269a49debd9fe8e66b19d4bbf532e", null ]
];