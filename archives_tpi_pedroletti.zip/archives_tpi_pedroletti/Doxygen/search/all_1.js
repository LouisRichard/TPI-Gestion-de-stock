var searchData=
[
  ['_28_24user_5b_27status_27_5d_29_7',['($user[&apos;status&apos;])',['../admin_panel_8php.html#a3ba41735a175b3f9de7b5103cf02c1be',1,'adminPanel.php']]],
  ['_28isset_28_24brands_29_29_8',['(isset($brands))',['../new_consumable_8php.html#ab2301c56c820e9cc61c54a04fecb6127',1,'newConsumable.php']]],
  ['_28isset_28_24consumabletypes_29_29_9',['(isset($consumableTypes))',['../new_consumable_8php.html#abbe8e99458c4365919f90edf8d8fc4cb',1,'newConsumable.php']]],
  ['_28isset_28_24products_29_29_10',['(isset($products))',['../new_consumable_8php.html#ada4840253cd43aec0474b72b9e9234fa',1,'newConsumable.php']]]
];
