var searchData=
[
  ['saveadminmodification_54',['saveAdminModification',['../users_8php.html#abfd1f5041482d929b5309b17287122e4',1,'users.php']]],
  ['setstatususeradmin_55',['setStatusUserAdmin',['../users_manager_8php.html#aee7253bd3b242ee474676bfa143bd6be',1,'usersManager.php']]],
  ['setstock_2ephp_56',['setStock.php',['../set_stock_8php.html',1,'']]]
];
