var searchData=
[
  ['changeusersstatus_2ephp_16',['changeUsersStatus.php',['../change_users_status_8php.html',1,'']]],
  ['consumables_2ephp_17',['consumables.php',['../consumables_8php.html',1,'']]],
  ['consumablesmanager_2ephp_18',['consumablesManager.php',['../consumables_manager_8php.html',1,'']]],
  ['content_19',['content',['../home_8php.html#ac263e92df89b6812e36111e31953cf14',1,'home.php']]],
  ['createsession_20',['createSession',['../users_8php.html#a5a8cc179982b6acb5e68e9acdb8d08a7',1,'users.php']]]
];
