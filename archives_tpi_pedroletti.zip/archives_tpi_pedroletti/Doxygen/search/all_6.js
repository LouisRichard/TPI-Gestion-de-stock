var searchData=
[
  ['foreach_35',['foreach',['../admin_panel_8php.html#a06f65a3298df75efee15cec5ad5ff47d',1,'foreach():&#160;adminPanel.php'],['../home_8php.html#aa9264d3f1bb691a1931a126ac41721a4',1,'foreach():&#160;home.php'],['../home_8php.html#a780eb2a2b25bbb3fc35c9c44ee969721',1,'foreach():&#160;home.php']]]
];
