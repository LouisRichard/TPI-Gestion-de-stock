var searchData=
[
  ['newconsumable_101',['newConsumable',['../consumables_8php.html#a90bb3186d42ee24e09fb43550ead68d8',1,'consumables.php']]]
];
