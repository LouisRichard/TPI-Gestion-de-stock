var searchData=
[
  ['addnewuser_2ephp_62',['addNewUser.php',['../add_new_user_8php.html',1,'']]],
  ['adminpanel_2ephp_63',['adminPanel.php',['../admin_panel_8php.html',1,'']]]
];
