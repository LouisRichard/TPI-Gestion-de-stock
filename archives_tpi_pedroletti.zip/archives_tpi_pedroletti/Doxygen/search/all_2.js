var searchData=
[
  ['addconsumable_11',['addConsumable',['../consumables_manager_8php.html#af5285b4e1f980afe5b0284d1a3208e3b',1,'consumablesManager.php']]],
  ['addnewuser_2ephp_12',['addNewUser.php',['../add_new_user_8php.html',1,'']]],
  ['adduser_13',['addUser',['../add_new_user_8php.html#a24c3ff16b51b5f025e82fbf9ef31e154',1,'addNewUser.php']]],
  ['adminpanel_2ephp_14',['adminPanel.php',['../admin_panel_8php.html',1,'']]],
  ['adverification_15',['adVerification',['../users_manager_8php.html#a92aab3e3d8f53469c9af814fc33fdba5',1,'usersManager.php']]]
];
