var searchData=
[
  ['newconsumable_51',['newConsumable',['../consumables_8php.html#a90bb3186d42ee24e09fb43550ead68d8',1,'consumables.php']]],
  ['newconsumable_2ephp_52',['newConsumable.php',['../new_consumable_8php.html',1,'']]]
];
