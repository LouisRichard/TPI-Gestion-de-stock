var indexSectionsWithContent =
{
  0: "$(acdefghilnostu",
  1: "acdehilnstu",
  2: "acdeglnosu",
  3: "$(cefi"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables"
};

