var searchData=
[
  ['getallconsumables_36',['getAllConsumables',['../display_request_manager_8php.html#af9c6fca62b956e77628907f450ea0d4e',1,'displayRequestManager.php']]],
  ['getbrands_37',['getBrands',['../display_request_manager_8php.html#a35904b014f4ed06ee34df75a1d68ad35',1,'displayRequestManager.php']]],
  ['getconsumabletypes_38',['getConsumableTypes',['../display_request_manager_8php.html#af56e3591ef04a3e2c7b16873e5121bcc',1,'displayRequestManager.php']]],
  ['getproducts_39',['getProducts',['../display_request_manager_8php.html#a9686a480a1adb1923d64e71cf0624275',1,'displayRequestManager.php']]],
  ['getproductsid_40',['getProductsId',['../consumables_manager_8php.html#ad6e77bc0770c19cf83826c3932510a4b',1,'consumablesManager.php']]],
  ['getuserinformation_41',['getUserInformation',['../users_manager_8php.html#a2868eedd64b8298c9c46556c84ed0748',1,'usersManager.php']]],
  ['getusersconnectioninformation_42',['getUsersConnectionInformation',['../users_manager_8php.html#a432b2c385deacf88f0b1b123884d5e44',1,'usersManager.php']]],
  ['getusersid_43',['getUsersID',['../users_manager_8php.html#ae5b3902b6ff7fd4a25b93defe7b429de',1,'usersManager.php']]],
  ['getusersinformation_44',['getUsersInformation',['../display_request_manager_8php.html#aff8789f625cbe53d0a9e2d7dd7f3fe8b',1,'displayRequestManager.php']]]
];
