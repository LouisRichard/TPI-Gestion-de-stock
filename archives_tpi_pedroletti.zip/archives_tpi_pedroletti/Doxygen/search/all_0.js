var searchData=
[
  ['_24content_0',['$content',['../admin_panel_8php.html#a57b284fe00866494b33afa80ba729bed',1,'$content():&#160;adminPanel.php'],['../home_8php.html#a57b284fe00866494b33afa80ba729bed',1,'$content():&#160;home.php'],['../new_consumable_8php.html#a57b284fe00866494b33afa80ba729bed',1,'$content():&#160;newConsumable.php']]],
  ['_24i_1',['$i',['../home_8php.html#a83018d9153d17d91fbcf3bc10158d34f',1,'home.php']]],
  ['_24id_2',['$id',['../change_users_status_8php.html#ae97941710d863131c700f069b109991e',1,'changeUsersStatus.php']]],
  ['_24query_3',['$query',['../set_stock_8php.html#af59a5f7cd609e592c41dc3643efd3c98',1,'setStock.php']]],
  ['_24status_4',['$status',['../change_users_status_8php.html#a58391ea75f2d29d5d708d7050b641c33',1,'changeUsersStatus.php']]],
  ['_24strsep_5',['$strSep',['../set_stock_8php.html#a2c1a39de519176a6331e7495123530b5',1,'setStock.php']]],
  ['_24userid_6',['$userId',['../set_stock_8php.html#a84651f4070d04080f6c5fd3c98cc9104',1,'setStock.php']]]
];
