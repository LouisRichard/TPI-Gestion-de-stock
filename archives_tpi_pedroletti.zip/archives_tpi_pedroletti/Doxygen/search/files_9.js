var searchData=
[
  ['template_2ephp_76',['template.php',['../template_8php.html',1,'']]]
];
