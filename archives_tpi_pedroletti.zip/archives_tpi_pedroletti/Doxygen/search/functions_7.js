var searchData=
[
  ['opendbconnexion_102',['openDBConnexion',['../db_connector_8php.html#ac86d33cb4865279fe9c2bde1d1e8d14d',1,'dbConnector.php']]]
];
