var searchData=
[
  ['template_2ephp_57',['template.php',['../template_8php.html',1,'']]]
];
