var searchData=
[
  ['addconsumable_79',['addConsumable',['../consumables_manager_8php.html#af5285b4e1f980afe5b0284d1a3208e3b',1,'consumablesManager.php']]],
  ['adduser_80',['addUser',['../add_new_user_8php.html#a24c3ff16b51b5f025e82fbf9ef31e154',1,'addNewUser.php']]],
  ['adverification_81',['adVerification',['../users_manager_8php.html#a92aab3e3d8f53469c9af814fc33fdba5',1,'usersManager.php']]]
];
