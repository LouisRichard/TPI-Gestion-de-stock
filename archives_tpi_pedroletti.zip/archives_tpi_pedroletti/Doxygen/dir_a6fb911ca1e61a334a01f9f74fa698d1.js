var dir_a6fb911ca1e61a334a01f9f74fa698d1 =
[
    [ "addNewUser.php", "add_new_user_8php.html", "add_new_user_8php" ],
    [ "changeUsersStatus.php", "change_users_status_8php.html", "change_users_status_8php" ],
    [ "consumablesManager.php", "consumables_manager_8php.html", "consumables_manager_8php" ],
    [ "dbConnector.php", "db_connector_8php.html", "db_connector_8php" ],
    [ "displayRequestManager.php", "display_request_manager_8php.html", "display_request_manager_8php" ],
    [ "encryption.php", "encryption_8php.html", "encryption_8php" ],
    [ "setStock.php", "set_stock_8php.html", "set_stock_8php" ],
    [ "usersManager.php", "users_manager_8php.html", "users_manager_8php" ]
];