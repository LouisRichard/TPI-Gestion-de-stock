var add_new_user_8php =
[
    [ "addUser", "add_new_user_8php.html#a24c3ff16b51b5f025e82fbf9ef31e154", null ],
    [ "userAlreadyExist", "add_new_user_8php.html#a411b6556aff2a0c69534aee5bdbd976f", null ]
];