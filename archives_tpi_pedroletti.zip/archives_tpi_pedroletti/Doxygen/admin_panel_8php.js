var admin_panel_8php =
[
    [ "$content", "admin_panel_8php.html#a57b284fe00866494b33afa80ba729bed", null ],
    [ "($user['status'])", "admin_panel_8php.html#a3ba41735a175b3f9de7b5103cf02c1be", null ],
    [ "endforeach", "admin_panel_8php.html#a672d9707ef91db026c210f98cc601123", null ],
    [ "endif", "admin_panel_8php.html#a82cd33ca97ff99f2fcc5e9c81d65251b", null ],
    [ "foreach", "admin_panel_8php.html#a06f65a3298df75efee15cec5ad5ff47d", null ]
];