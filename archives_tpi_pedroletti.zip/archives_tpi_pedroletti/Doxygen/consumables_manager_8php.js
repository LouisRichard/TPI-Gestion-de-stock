var consumables_manager_8php =
[
    [ "addConsumable", "consumables_manager_8php.html#af5285b4e1f980afe5b0284d1a3208e3b", null ],
    [ "getProductsId", "consumables_manager_8php.html#ad6e77bc0770c19cf83826c3932510a4b", null ]
];