var display_8php =
[
    [ "displayAdminPanel", "display_8php.html#a1a9bf8cab6ee39269f6f26c4d0309f3b", null ],
    [ "displayHome", "display_8php.html#ac7ded7041968e04a468da2573b293b6c", null ],
    [ "displayLogin", "display_8php.html#a321a79ac79f01780890341035eb5c418", null ],
    [ "displayNewConsumable", "display_8php.html#ae3619f23d0ba85da191a4545b7877912", null ]
];